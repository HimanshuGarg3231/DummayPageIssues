import styled from 'styled-components';

const IssueAnchorNTitleWrapper = styled.div`
  display : flex;
  flex-direction : row;
  align-items: baseline;
  padding-top: 2px;
`;

export default IssueAnchorNTitleWrapper;
